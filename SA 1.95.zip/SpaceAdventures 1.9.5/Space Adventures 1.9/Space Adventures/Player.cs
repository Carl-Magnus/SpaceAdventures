﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Space_Adventures
{
    class Player : MovingObject
    {
        GameWorld gw;

        Camera camera;

        private Vector2 startPos;

        public int life = 100;

        bool shootRight = true;
        bool shootLeft = false;

        public Player(Texture2D tex, Vector2 pos, Rectangle rect, GameWorld gw, GameWindow window, Camera camera) : base(tex, pos, rect, window)
        {
            this.tex = tex;
            this.gw = gw;
            this.window = window;
            this.camera = camera;
            this.rect = rect;

            startPos = pos;
        }

        public override void Update(GameTime gameTime)
        {
            //Movement
            if ((ks.IsKeyDown(Keys.Right) && (pos.X + rect.Width) <= 3800) /*|| PS4Mono.InputManager.GamepadCheck(0, Buttons.DPadRight) && (pos.X + rect.Width) <= 3800*/)
            {
                speed.X = 4;
                shootRight = true;
                shootLeft = false;

                //Animation
                if (frameTimer <= 0)
                {
                    frame2 = 2;
                    rect.Y = (frame2 % 2) * rect.Height;

                    frameTimer = frameInterval;
                    frame++;
                    rect.X = (frame % 6) * rect.Width;
                }

            }
            else if ((ks.IsKeyDown(Keys.Left) && pos.X >= rect.Width) /*|| PS4Mono.InputManager.GamepadCheck(0, Buttons.DPadLeft) && (pos.X >= rect.Width)*/)
            {
                speed.X = -4;
                shootRight = false;
                shootLeft = true;

                //Animation
                if (frameTimer <= 0)
                {
                    frame2 = 1;
                    rect.Y = (frame2 % 2) * rect.Height;

                    frameTimer = frameInterval;
                    frame++;
                    rect.X = (frame % 6) * rect.Width;
                }
            }

            if (pos.Y - rect.Height <= (800 - camera.levelBounds.Bottom))
            {
                speed.Y += 0.2f;
            }

            ////Shoot upwards
            //if (ks.IsKeyDown(Keys.Z) || PS4Mono.InputManager.GamepadCheck(0, Buttons.DPadUp))
            //{
            //    //shootUp = true;
            //}
            //else
            //{
            //    //shootUp = false;
            //}

            //Jump
            if (ks.IsKeyDown(Keys.Up) && isOnGround /*|| PS4Mono.InputManager.GamepadCheck(0, Buttons.A) && isOnGround*/)
            {
                speed.Y = -7;
                isOnGround = false;
            }
            //Stay above ground
            if (hitBox.Y + hitBox.Height > bY)
            {
                pos.Y = bY - hitBox.Height;
                isOnGround = true;
                speed.Y = 0;
            }

            oldks = ks;
            ks = Keyboard.GetState();

            //Shoots a bullet from the players gun            
            if (Keyboard.GetState().IsKeyDown(Keys.Space) && !oldks.IsKeyDown(Keys.Space) /*|| PS4Mono.InputManager.GamepadCheck(0, Buttons.X)*/)
            {
                gw.Shoot(pos, shootRight, shootLeft);
            }

            camera.SetPos(pos);

            pos += speed;
            speed.X = 0;
            speed.Y += 0.2f;

            frameTimer -= timer;

            hitBox.X = (int)pos.X;
            hitBox.Y = (int)(pos.Y >= 0 ? pos.Y + 0.9f : pos.Y - 0.9f);
        }

        public override void Draw(SpriteBatch sb)
        {
            sb.Draw(tex, pos, rect, Color.White);
        }

        public void Hurt()
        {
            pos = startPos;
            life -= 25;

            Game1.hp -= 25;
        }
    }
}
