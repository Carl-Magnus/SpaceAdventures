﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Space_Adventures
{
    class Enemies : MovingObject
    {
        protected int chickenWalk = 100;
        protected int greenmanWalk = 300;

        protected bool enemyAlive = true;

        protected bool chickenHit = false;
        protected int chickenLife;

        public Enemies(Texture2D tex, Vector2 pos, Rectangle rect, GameWindow window) : base(tex, pos, rect, window)
        {
            this.tex = tex;
            this.rect = rect;

            hitBox = rect;
        }

        public override void Update(GameTime gameTime)
        {

        }

        public override void Draw(SpriteBatch sb)
        {
            sb.Draw(tex, pos, rect, Color.White);
        }
    }
}
