﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Space_Adventures
{
    class Bullet : GameObject
    {
        Vector2 bulletCentrum;

        bool shootRight;
        bool shootLeft;
        bool shootUp = false;

        double direction;
        float bulletSpeed;

        public Bullet(Texture2D tex, Vector2 pos, bool shootRight, bool shootLeft) : base (tex, pos)
        {
            this.tex = tex;
            this.pos = pos;
            this.shootRight = shootRight;
            this.shootLeft = shootLeft;

            bulletSpeed = 8;
        }

        public override void Update(GameTime gameTime)
        {
            bulletCentrum = new Vector2(0, tex.Height);

            if (shootRight && !shootUp && !shootLeft)
            {
                direction = 1;
                pos.X += bulletSpeed * (float)direction;
            }

            if (shootLeft && !shootUp && !shootRight)
            {
                direction = -1;
                pos.X += bulletSpeed * (float)direction;
            }

            if (shootUp)
            {
                pos.Y -= bulletSpeed;
            }

            hitBox.X = (int)pos.X;
            hitBox.Y = (int)pos.Y;
        }

        public override void Draw(SpriteBatch sb)
        {
            sb.Draw(tex, pos, Color.White);
        }
    }
}
