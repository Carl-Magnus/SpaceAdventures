﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Space_Adventures
{
    abstract class GameObject
    {
        protected Texture2D tex;
        protected Vector2 pos;
        protected Rectangle hitBox;

        protected Rectangle rect;

        public GameObject(Texture2D tex, Vector2 pos)
        {
            this.pos = pos;

            hitBox = new Rectangle((int)pos.X, (int)pos.Y, tex.Width, tex.Height);
        }

        public virtual bool IsColliding(Platform plat)
        {
            return hitBox.Intersects(plat.hitBox);
        }

        public virtual void HandleCollision(Platform other)
        {
            hitBox.Y = other.hitBox.Y - hitBox.Height;
            pos.Y = hitBox.Y;
        }

        public virtual bool badCollision(Enemy e)
        {
            return hitBox.Intersects(e.hitBox);
        }

        public virtual bool PixelCollision(MovingObject other)
        {
            Color[] dataA = new Color[tex.Width * tex.Height];
            tex.GetData(dataA);
            Color[] dataB = new Color[other.tex.Width * other.tex.Height];
            other.tex.GetData(dataB);

            int top = Math.Max(hitBox.Top, other.hitBox.Top);
            int bottom = Math.Min(hitBox.Bottom, other.hitBox.Bottom);
            int left = Math.Max(hitBox.Left, other.hitBox.Left);
            int right = Math.Min(hitBox.Right, other.hitBox.Right);

            for (int y = top; y < bottom; y++)
            {
                for (int x = left; x < right; x++)
                {
                    Color colorA = dataA[(rect.X + x - hitBox.Left) + (rect.Y + y - hitBox.Top) * tex.Width]; //tittar åt vänster, spelet krashar
                    Color colorB = dataB[(other.rect.X + x - other.hitBox.Left) + (other.rect.Y + y - other.hitBox.Top) * other.tex.Width];

                    if (colorA.A != 0 && colorB.A != 0)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        public abstract void Update(GameTime gameTime);

        public abstract void Draw(SpriteBatch sb);
    }
}
