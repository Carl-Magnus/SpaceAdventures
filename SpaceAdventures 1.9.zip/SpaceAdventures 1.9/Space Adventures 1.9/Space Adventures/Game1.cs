﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Space_Adventures
{
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Texture2D playerTex, platTex, backgroundTex, chickenTex, greenmanTex, bulletTex;

        GameWorld gameWorld;

        Background background;

        KeyboardState ks;

        Camera camera;
        Viewport view;

        SpriteFont spriteFont;
        string text;

        public static int hp = 100;

        enum Gamestate { Start, Ingame, GameOver };
        Gamestate gs = Gamestate.Start;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            PS4Mono.InputManager.Initialize(this);
            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            background = new Background(Content, Window);

            playerTex = Content.Load<Texture2D>("PlayerSheetFinal");
            platTex = Content.Load<Texture2D>("Platform1");
            chickenTex = Content.Load<Texture2D>("ChickenWalkFull");
            greenmanTex = Content.Load<Texture2D>("GreenManWalk");
            bulletTex = Content.Load<Texture2D>("BlueBullet");

            view = GraphicsDevice.Viewport;
            camera = new Camera(view);

            spriteFont = Content.Load<SpriteFont>("spriteFont");

            gameWorld = new GameWorld(playerTex, platTex, bulletTex, backgroundTex, chickenTex, greenmanTex, Window, background, camera);
        }

        protected override void UnloadContent()
        {

        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            ks = Keyboard.GetState();

            PS4Mono.InputManager.Update();

            switch (gs)
            {
                case Gamestate.Start:

                    if (ks.IsKeyDown(Keys.Enter))
                    {
                        gs = Gamestate.Ingame;
                    }

                    break;

                case Gamestate.Ingame:

                    gameWorld.Update(gameTime);

                    if (gameWorld.isGameOver())
                    {
                        gs = Gamestate.GameOver;
                    }

                    break;

                case Gamestate.GameOver:

                    if (ks.IsKeyDown(Keys.Enter))
                    {
                        hp = 100;
                        gameWorld.gameRestart();
                        gs = Gamestate.Ingame;
                    }
                    break;
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            switch (gs)
            {
                case Gamestate.Start:
                    spriteBatch.Begin();

                    text = "Press Enter!";
                    spriteBatch.DrawString(spriteFont, text, new Vector2((Window.ClientBounds.Width / 2) - (spriteFont.MeasureString(text).X / 2), (Window.ClientBounds.Height / 2) - (spriteFont.MeasureString(text).Y / 2)), Color.Black);

                    spriteBatch.End();
                    break;

                case Gamestate.Ingame:
                    spriteBatch.Begin(SpriteSortMode.Deferred, null, null, null, null, null, camera.GetTransform());

                    gameWorld.Draw(spriteBatch);

                    text = "Health: " + hp;
                    spriteBatch.DrawString(spriteFont, text, new Vector2(250, 300), Color.Black); 

                    spriteBatch.End();
                    break;

                case Gamestate.GameOver:
                    spriteBatch.Begin();

                    text = "Press Enter!";
                    spriteBatch.DrawString(spriteFont, text, new Vector2((Window.ClientBounds.Width / 2) - (spriteFont.MeasureString(text).X / 2), (Window.ClientBounds.Height / 2) - (spriteFont.MeasureString(text).Y / 2)), Color.Black);

                    spriteBatch.End();
                    break;
            }

            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}
