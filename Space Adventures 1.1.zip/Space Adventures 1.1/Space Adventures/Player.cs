﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Space_Adventures
{
    class Player : GameObject
    {
        GameWindow window;

        Vector2 speed;

        KeyboardState ks;

        Camera camera;

        int bX, bY;
        bool isOnGround;

        public Player(Texture2D tex, Vector2 pos, GameWindow window, Camera camera) : base(tex, pos)
        {
            this.tex = tex;
            this.window = window;
            this.camera = camera;

            bX = window.ClientBounds.Width;
            bY = window.ClientBounds.Height;
        }

        public override void HandleCollision(Platform plat)
        {
            isOnGround = true;
            speed.Y = 0;
            base.HandleCollision(plat);
            hitBox.X = (int)pos.X;
        }

        public override void Update(GameTime gameTime)
        {
            ks = Keyboard.GetState();

            //Movement
            if (ks.IsKeyDown(Keys.Right) && (pos.X + tex.Width) < bX)
            {
                speed.X = 3;
            }
            else if (ks.IsKeyDown(Keys.Left) && (pos.X) > 0)
            {
                speed.X = -3;
            }

            //Jump
            if (ks.IsKeyDown(Keys.Space) && isOnGround)
            {
                speed.Y = -7;
                isOnGround = false;
            }
            //Stay above ground
            if (hitBox.Y + hitBox.Height > bY)
            {
                pos.Y = bY - hitBox.Height;
                isOnGround = true;
                speed.Y = 0;
            }

            camera.SetPos(pos);

            pos += speed;
            speed.X = 0;
            speed.Y += 0.2f;

            hitBox.X = (int)pos.X;
            hitBox.Y = (int)(pos.Y >= 0 ? pos.Y + 0.9f : pos.Y - 0.9f);
        }

        public override void Draw(SpriteBatch sb)
        {
            sb.Draw(tex, pos, Color.White);

        }
    }
}
