﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Space_Adventures
{
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Texture2D playerTex, platTex, chickenTex, greenmanTex, bulletTex, titleTex, menuTex, startTex, spikeTex, victoryTex;

        Song darkSong;

        GameWorld gameWorld;

        Background background;

        KeyboardState ks;

        Camera camera;
        Viewport view;

        SpriteFont spriteFont;
        string text;

        public static int hp = 100;

        enum Gamestate { Start, Ingame, GameOver };
        Gamestate gs = Gamestate.Start;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

        }

        protected override void Initialize()
        {
            PS4Mono.InputManager.Initialize(this);
            base.Initialize();
          
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            background = new Background(Content, Window);

            playerTex = Content.Load<Texture2D>("PlayerSheetFinal");
            platTex = Content.Load<Texture2D>("Platform1");
            chickenTex = Content.Load<Texture2D>("ChickenWalkFull");
            greenmanTex = Content.Load<Texture2D>("GreenManWalk");
            bulletTex = Content.Load<Texture2D>("BlueBullet");
            titleTex = Content.Load<Texture2D>("Title");
            menuTex = Content.Load<Texture2D>("MenuBG");
            startTex = Content.Load<Texture2D>("StartText");
            spikeTex = Content.Load<Texture2D>("Spikes");
            victoryTex = Content.Load<Texture2D>("VictoryScreen");

            //darkSong = Content.Load<Song>("Music1");
            //MediaPlayer.Play(darkSong);
            //MediaPlayer.IsRepeating = true;
            //MediaPlayer.MediaStateChanged += MediaPlayer_MediaStateChanged;

            view = GraphicsDevice.Viewport;
            camera = new Camera(view);

            spriteFont = Content.Load<SpriteFont>("spriteFont");

            gameWorld = new GameWorld(playerTex, platTex, bulletTex, chickenTex, greenmanTex, spikeTex, Window, background, camera, this);
        }

        void MediaPlayer_MediaStateChanged(object sender, System.EventArgs e)
        {
            // 0.0f is silent, 1.0f is full volume
            MediaPlayer.Volume -= 0.1f;
            MediaPlayer.Play(darkSong);
        }

        protected override void UnloadContent()
        {

        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            ks = Keyboard.GetState();

            PS4Mono.InputManager.Update();

            switch (gs)
            {
                case Gamestate.Start:

                    if (ks.IsKeyDown(Keys.Enter))
                    {   
                        gs = Gamestate.Ingame;
                    }

                    break;

                case Gamestate.Ingame:

                    gameWorld.Update(gameTime);

                    if (gameWorld.WinGame())
                    {
                            gs = Gamestate.GameOver; 
                    }
                    if (gameWorld.isGameOver())
                    {
                        hp = 100;
                        gameWorld.gameRestart();
                        gs = Gamestate.Start;
                    }

                    break;

                case Gamestate.GameOver:

                    if (ks.IsKeyDown(Keys.Enter))
                    {
                        hp = 100;
                        gameWorld.gameRestart();
                        gs = Gamestate.Ingame;
                    }
                    break;
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            switch (gs)
            {
                case Gamestate.Start:
                    spriteBatch.Begin();

                    spriteBatch.Draw(menuTex, Vector2.Zero, Color.White);
                    spriteBatch.Draw(titleTex, new Vector2 (30, 100), Color.White);
                    spriteBatch.Draw(startTex, new Vector2(80, 300), Color.White);
                    

                    spriteBatch.End();
                    break;

                case Gamestate.Ingame:
                    spriteBatch.Begin(SpriteSortMode.Deferred, null, null, null, null, null, camera.GetTransform());

                    gameWorld.Draw(spriteBatch);

                    text = "Health: " + hp;
                    spriteBatch.DrawString(spriteFont, text, new Vector2(250, 300), Color.Black); 

                    spriteBatch.End();
                    break;

                case Gamestate.GameOver:
                    spriteBatch.Begin();

                    spriteBatch.Draw(menuTex, Vector2.Zero, Color.White);
                    spriteBatch.Draw(startTex, new Vector2(80, 300), Color.White);
                    spriteBatch.Draw(victoryTex, new Vector2(100, 200), Color.White);

                    spriteBatch.End();
                    break;
            }

            spriteBatch.End();
            base.Draw(gameTime);
        }

        public void MusicPlayer()
        {
            //MediaPlayer.Play(darkSong);
            //MediaPlayer.IsRepeating = true;
            //MediaPlayer.MediaStateChanged += MediaPlayer_MediaStateChanged;
        }
    }
}
