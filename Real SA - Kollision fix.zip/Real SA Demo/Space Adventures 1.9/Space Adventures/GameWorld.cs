﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Media;

namespace Space_Adventures
{
    class GameWorld
    {
        GameWindow window;

        Texture2D playerTex;
        Texture2D platTex;
        Texture2D chickenTex;
        Texture2D greenmanTex;
        Texture2D bulletTex;
        Texture2D spikeTex;

        Player player;
        Bullet bullet;

        Platform plat;
        BadPlatform badPlat;
        Chicken chicken;
        Greenman greenman;

        Game1 game1;

        Background background;

        Camera camera;

        List<Bullet> bulletList = new List<Bullet>();
        List<Platform> platList = new List<Platform>();
        List<BadPlatform> badPlatList = new List<BadPlatform>();

        List<Chicken> chickenList = new List<Chicken>();
        List<Greenman> greenmanList = new List<Greenman>();

        public GameWorld(Texture2D playerTex, Texture2D platTex, Texture2D bulletTex, Texture2D chickenTex, Texture2D greenmanTex, Texture2D spikeTex, GameWindow window, 
            Background background, Camera camera, Game1 game1)
        {
            this.playerTex = playerTex;
            this.platTex = platTex;
            this.chickenTex = chickenTex;
            this.greenmanTex = greenmanTex;
            this.bulletTex = bulletTex;
            this.spikeTex = spikeTex;
            this.window = window;
            this.background = background;
            this.camera = camera;
            this.game1 = game1;

            LoadObjects();
        }

        public virtual void Update(GameTime gameTime)
        {
            background.Update();

            game1.MusicPlayer();

            player.Update(gameTime);

            foreach (Platform plat in platList)
            {
                if (player.IsColliding(plat))
                {
                    player.HandleCollision(plat);                                                         
                }

                foreach (Chicken c in chickenList)
                {
                    if (c.IsColliding(plat))
                    {
                        c.HandleCollision(plat);
                    }
                }

                foreach (Greenman g in greenmanList)
                {
                    if (g.IsColliding(plat))
                    {
                        g.HandleCollision(plat);
                    }
                }
            }
            foreach (BadPlatform badPlat in badPlatList)
            {
                if (player.IsCollidingBad(badPlat))
                {
                    player.Hurt();
                }
            }
             
           
            for (int i = chickenList.Count - 1; i >= 0; i--)
            {
                chickenList[i].Update(gameTime);

                if (player.badCollision(chickenList[i]))
                {
                    if (player.PixelCollision(chickenList[i]))
                    {
                        player.Hurt();
                    }
                }

                for (int j = bulletList.Count - 1; j >= 0; j--)
                {
                    if (bulletList[j].badCollision(chickenList[i]))
                    {
                        bulletList.RemoveAt(j);
                    }
                }

                if (!chickenList[i].EnemyAlive)
                {
                    chickenList.RemoveAt(i);
                }
            }

            for (int i = platList.Count -1; i >= 0; i--)
            {
                for (int j = bulletList.Count - 1; j >= 0; j--)
                {
                    if (bulletList[j].IsColliding(platList[i]))
                    {
                        bulletList.RemoveAt(j);
                    }
                }
            }
            

            for (int i = greenmanList.Count - 1; i >= 0; i--)
            {
                greenmanList[i].Update(gameTime);

                if (player.badCollision(greenmanList[i]))
                {
                    if (player.PixelCollision(greenmanList[i]))
                    {
                        player.Hurt();
                    }
                }

                for (int j = bulletList.Count - 1; j >= 0; j--)
                {
                    if (bulletList[j].badCollision(greenmanList[i]))
                    {
                        bulletList.RemoveAt(j);
                    }
                }

                if (!greenmanList[i].EnemyAlive)
                {
                    greenmanList.RemoveAt(i);
                }
            }

            EnemyShot(gameTime);
        }

        public virtual void Draw(SpriteBatch sb)
        {
            background.Draw(sb);

            foreach (Platform plat in platList)
            {
                plat.Draw(sb);
            }

            foreach (BadPlatform badPlat in badPlatList)
            {
                badPlat.Draw(sb);
            }

            foreach (Chicken chick in chickenList)
            {
                chick.Draw(sb);
            }

            foreach (Greenman greenm in greenmanList)
            {
                greenm.Draw(sb);
            }

            foreach (Bullet b in bulletList)
            {
                b.Draw(sb);
            }

            player.Draw(sb);
        }

        #region LevelOne
        public void LoadObjects()   
        {
            StreamReader sr = new StreamReader("Platforms.txt");
            string s = sr.ReadLine();
            string[] coordinates = s.Split(';');

            for (int i = 0; i < coordinates.Length; i++)
            {
                string[] xywh = coordinates[i].Split(',');
                try
                {
                    int x = Convert.ToInt32(xywh[0]);
                    int y = Convert.ToInt32(xywh[1]);
                    int w = Convert.ToInt32(xywh[2]);
                    int h = Convert.ToInt32(xywh[3]);
                    Vector2 pos = new Vector2(x, y);
                    Rectangle rect = new Rectangle(x, y, w, h);
                    Console.WriteLine("" + pos);

                    plat = new Platform(platTex, pos, rect);
                    platList.Add(plat);
                }
                catch (FormatException e)
                {
                    Console.WriteLine("Input string is not a sequence of digits.");
                }
            }

            //Reads damaging platfroms from file
            sr = new StreamReader("BadPlatforms.txt");
            s = sr.ReadLine();
            coordinates = s.Split(';');

            for (int i = 0; i < coordinates.Length; i++)
            {
                string[] xywh = coordinates[i].Split(',');
                try
                {
                    int x = Convert.ToInt32(xywh[0]);
                    int y = Convert.ToInt32(xywh[1]);
                    int w = Convert.ToInt32(xywh[2]);
                    int h = Convert.ToInt32(xywh[3]);
                    Vector2 pos = new Vector2(x, y);
                    Rectangle rect = new Rectangle(x, y, w, h);
                    Console.WriteLine("" + pos);

                    badPlat = new BadPlatform(spikeTex, pos, rect);
                    badPlatList.Add(badPlat);
                }
                catch (FormatException e)
                {
                    Console.WriteLine("Input string is not a sequence of digits.");
                }
            }

            Rectangle playerRect = new Rectangle(0, 0, 30, 43);

            sr = new StreamReader("Player.txt");
            s = sr.ReadLine();
            coordinates = s.Split(';');

            for (int i = 0; i < coordinates.Length; i++)
            {
                string[] xywh = coordinates[i].Split(',');
                try
                {
                    int x = Convert.ToInt32(xywh[0]);
                    int y = Convert.ToInt32(xywh[1]);
                    Vector2 pos = new Vector2(x, y);

                    Console.WriteLine("" + pos);

                    player = new Player(playerTex, pos, playerRect, this, window, camera);
                }
                catch (FormatException e)
                {
                    Console.WriteLine("Input string is not a sequence of digits.");
                }
            }

            Rectangle chickenRect = new Rectangle(0, 0, 54, 45);

            sr = new StreamReader("Enemy.txt");
            s = sr.ReadLine();
            coordinates = s.Split(';');

            for (int i = 0; i < coordinates.Length; i++)
            {
                string[] xywh = coordinates[i].Split(',');
                try
                {
                    int x = Convert.ToInt32(xywh[0]);
                    int y = Convert.ToInt32(xywh[1]);
                    Vector2 pos = new Vector2(x, y);

                    Console.WriteLine("" + pos);

                    chicken = new Chicken(chickenTex, pos, chickenRect, window, 100);
                    chickenList.Add(chicken);
                }
                catch (FormatException e)
                {
                    Console.WriteLine("Input string is not a sequence of digits.");
                }
            }

            Rectangle greenmanRect = new Rectangle(0, 0, 60, 67);

            sr = new StreamReader("Boss.txt");
            s = sr.ReadLine();
            coordinates = s.Split(';');

            for (int i = 0; i < coordinates.Length; i++)
            {
                string[] xywh = coordinates[i].Split(',');
                try
                {
                    int x = Convert.ToInt32(xywh[0]);
                    int y = Convert.ToInt32(xywh[1]);
                    Vector2 pos = new Vector2(x, y);

                    Console.WriteLine("" + pos);

                    greenman = new Greenman(greenmanTex, pos, greenmanRect, window, 400);
                    greenmanList.Add(greenman);
                }
                catch (FormatException e)
                {
                    Console.WriteLine("Input string is not a sequence of digits.");
                }
            }
        }
        #endregion LevelOne

        public bool isGameOver()
        {
            if (player.life == 0)
            {
                return true;
            }

            return false;
        }

        public void gameRestart()
        {
            player.life = 100;

            platList.Clear();
            badPlatList.Clear();
            chickenList.Clear();
            greenmanList.Clear();
            bulletList.Clear();

            LoadObjects();
        }

        public void Shoot(Vector2 pos, bool shootRight, bool shootLeft)
        {
            bullet = new Bullet(bulletTex, new Vector2(pos.X + 15, pos.Y + 20), shootRight, shootLeft);

            bulletList.Add(bullet);
        }

        public void EnemyShot(GameTime gameTime)
        {
            for (int i = bulletList.Count - 1; i >= 0; i--)
            {
                bulletList[i].Update(gameTime);

                for (int j = chickenList.Count - 1; j >= 0; j--)
                {
                    if (bulletList[i].badCollision(chickenList[j]))
                    {
                        chickenList[j].Hurt();
                    }
                }
            }

            for (int i = bulletList.Count - 1; i >= 0; i--)
            {
                for (int k = greenmanList.Count - 1; k >= 0; k--)
                {
                    if (bulletList[i].badCollision(greenmanList[k]))
                    {
                        greenmanList[k].Hurt();
                    }
                }
            }

        }

        public bool WinGame()
        {
            if(greenmanList.Count == 0)
            {
                return true;
            }
            return false;
        }
    }
}
